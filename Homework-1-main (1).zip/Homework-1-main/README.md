# Homework-1

This is a repository for homework 1 of DATA599-3
